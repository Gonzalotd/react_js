import Menu from "./Menu";

export default function About() {

    return (
        <div>
            <Menu />
            <h1>Acerca del Autor de la página....</h1>
        </div>
    )
}