import Menu from "./Menu";

export default function Home() {

    return (
       <div>
            <Menu />
            <h1> Bienvenido a React Router</h1>
       </div>
    )
}