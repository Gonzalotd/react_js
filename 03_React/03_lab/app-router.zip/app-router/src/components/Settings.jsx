import Menu from "./Menu";

export default function Settings() {

    return (
        <div>
            <Menu />
            <h2>Configuración de tu Perfil</h2>
        </div>
    )
}